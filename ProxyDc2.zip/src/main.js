import './assets/bootstrap_yeti.css'

import { createApp } from 'vue'
//import router from './router'

// import AppForm from './AppForm.vue'
// createApp(AppForm).mount('#app')

import AppDashboard from './AppDashboard.vue'
createApp(AppDashboard).mount('#app')

//createApp(App).use(router).mount('#app')
//createApp(App).mount('#app')